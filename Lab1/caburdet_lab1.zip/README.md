## Run Act 1 with test:

node

.load lab1act2partA.js

.load lab1act2partA_test.js

## Run Act 2 with test:

node

.load lab1act2partB.js

.load lab1act2partB_test.js

## Run Act 3 with test:

node

.load lab1act2partC.js

.load lab1act2partC_test.js
