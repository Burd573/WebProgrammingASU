## Run Task 1 with test:

Navigate to Lab3 directory

node task1/task1server.js

## Run Task 2:

Navigate to Lab3 directory

node task2/task2server.js

## Run Task 3 :

Navigate to Lab3 directory

node task3/task3server.js

#

### Note:

All tasks use the groceries.json stored in the grocerydata directory. It is easiest to run all tasks from the Lab3 directory with the path to the appropriate subdirectory in the node command as shown above.
