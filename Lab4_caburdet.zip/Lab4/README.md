## Run Task 1:

Navigate to activity1 directory

npm install

npm start

## Run Task 2:

Navigate to activity2 directory

npm install

npm start

## Run Task 3 :

Navigate to activity3 directory

npm install

npm start

#

### Notes:

- Task 1 runs on port 3001
- Task 2 runs on port 3002
- Task 3 runs on port 3003
- All requirements complete except R4 on activity 3
