## Run Act 1 with test:

Navigate to Activity1 directory

node

.load NewsServiceAct1.js

.load NewsServiceAct1_test.js

## Run Act 2:

Navigate to Activity2 directory

node NewsServiceAct2.js

## Run Act 3 :

Navigate to Activity3 directory

node NewsServiceAct3.js
