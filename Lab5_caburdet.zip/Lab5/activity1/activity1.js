// 1. (6) Output to the console the <ol> element encompassing the results of the search
document.getElementsByTagName("ol")[0];
// 2. (6) Output to the console the number of <h2> tags in the page
document.getElementsByTagName("h2").length;
// 3. (6) Output to the console the value in the search bar
document.getElementById("sb_form_q").value;
// 4. (6) Make the "Microsoft Bing" logo and text in the upper left corner go away
document.getElementsByClassName("b_logoArea")[0].remove();
